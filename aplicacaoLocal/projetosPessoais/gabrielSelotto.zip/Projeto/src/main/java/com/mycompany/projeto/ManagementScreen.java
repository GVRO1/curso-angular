package com.mycompany.projeto;
// Projeto da Célia feito por Gabriel Selotto RA 01192114
import java.awt.Color;
import java.util.Random;


public class ManagementScreen extends javax.swing.JFrame 
{

    public ManagementScreen() 
    {
        initComponents();
    }
 
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        percentageCpu = new javax.swing.JLabel();
        percentageHd = new javax.swing.JLabel();
        percentageMemory = new javax.swing.JLabel();
        updateHdButton = new javax.swing.JButton();
        updateAllButton = new javax.swing.JButton();
        updateMemoryButton = new javax.swing.JButton();
        updateCpuButton = new javax.swing.JButton();

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane1.setViewportView(jTextArea1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 0, 51));
        jLabel1.setText("Basic Management System");

        jLabel2.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        jLabel2.setText("CPU Usage");

        jLabel3.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        jLabel3.setText("HD Usage");

        jLabel4.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        jLabel4.setText("Memory Usage");

        jLabel8.setText("Usage in %");

        jLabel9.setText("Usage in %");

        jLabel10.setText("Usage in %");

        percentageCpu.setFont(new java.awt.Font("Arial", 3, 18)); // NOI18N
        percentageCpu.setText("%");

        percentageHd.setFont(new java.awt.Font("Arial", 3, 18)); // NOI18N
        percentageHd.setText("%");

        percentageMemory.setFont(new java.awt.Font("Arial", 3, 18)); // NOI18N
        percentageMemory.setText("%");

        updateHdButton.setText("Update HD");
        updateHdButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                updateHdButtonMouseClicked(evt);
            }
        });

        updateAllButton.setText("Update All!");
        updateAllButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                updateAllButtonMouseClicked(evt);
            }
        });
        updateAllButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateAllButtonActionPerformed(evt);
            }
        });

        updateMemoryButton.setText("Update Memory");
        updateMemoryButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                updateMemoryButtonMouseClicked(evt);
            }
        });

        updateCpuButton.setText("Update CPU");
        updateCpuButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                updateCpuButtonMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel8))
                        .addGap(509, 509, 509))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(percentageCpu, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel9)
                                    .addComponent(percentageHd, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(168, 168, 168))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addComponent(updateCpuButton)
                                .addGap(130, 130, 130)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(updateAllButton)
                                    .addComponent(updateHdButton))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 155, Short.MAX_VALUE)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel4)
                                .addComponent(jLabel10, javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(percentageMemory, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(updateMemoryButton))
                        .addGap(20, 20, 20))))
            .addGroup(layout.createSequentialGroup()
                .addGap(203, 203, 203)
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jLabel4)
                    .addComponent(jLabel2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(jLabel9)
                    .addComponent(jLabel10))
                .addGap(25, 25, 25)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(percentageMemory, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(percentageHd, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(percentageCpu, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(updateHdButton)
                    .addComponent(updateCpuButton)
                    .addComponent(updateMemoryButton))
                .addGap(18, 18, 18)
                .addComponent(updateAllButton)
                .addGap(44, 44, 44))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void updateAllButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateAllButtonActionPerformed
        
    }//GEN-LAST:event_updateAllButtonActionPerformed

    private void updateAllButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_updateAllButtonMouseClicked
        getCpuUsage();
        getHdUsage();
        getMemoryUsage();
    }//GEN-LAST:event_updateAllButtonMouseClicked

    private void updateCpuButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_updateCpuButtonMouseClicked
        getCpuUsage();
    }//GEN-LAST:event_updateCpuButtonMouseClicked

    private void updateHdButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_updateHdButtonMouseClicked
        getHdUsage();
    }//GEN-LAST:event_updateHdButtonMouseClicked

    private void updateMemoryButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_updateMemoryButtonMouseClicked
        getMemoryUsage();
    }//GEN-LAST:event_updateMemoryButtonMouseClicked


    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ManagementScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new ManagementScreen().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JLabel percentageCpu;
    private javax.swing.JLabel percentageHd;
    private javax.swing.JLabel percentageMemory;
    private javax.swing.JButton updateAllButton;
    private javax.swing.JButton updateCpuButton;
    private javax.swing.JButton updateHdButton;
    private javax.swing.JButton updateMemoryButton;
    // End of variables declaration//GEN-END:variables

private int cpuUsage, hdUsage, memoryUsage, randCpu, randHd, randMemory;
        
Random random = new Random();
    

    private void getCpuUsage() 
    {
    randCpu = random.nextInt(101);
    cpuUsage = randCpu;
    setCpuUsage();
    }
        
    public void getHdUsage()
    {
    randHd = random.nextInt(101);
    hdUsage = randHd;
    setHdUsage();
    }
    
    public void getMemoryUsage()
    {
    randMemory = random.nextInt(101);
    memoryUsage = randMemory;
    setMemoryUsage();
    }
    
    public void setCpuUsage() 
    {
        percentageCpu.setText(Integer.toString(cpuUsage)+ "%");
    }
    
    public void setHdUsage() 
    {
        percentageHd.setText(Integer.toString(hdUsage)+ "%");
    }
    
    public void setMemoryUsage() 
    {
        percentageMemory.setText(Integer.toString(memoryUsage)+ "%");
    }
}

